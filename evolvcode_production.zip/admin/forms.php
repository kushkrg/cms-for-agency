<?php
/**
 * Evolvcode CMS - Admin Forms Management
 * 
 * CRUD operations for managing forms.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/Auth.php';

// Check authentication
Auth::requireLogin();

$db = Database::getInstance();
$error = '';
$success = '';

// Handle form actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!Security::validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'create':
            case 'update':
                $id = (int)($_POST['id'] ?? 0);
                $name = Security::clean($_POST['name'] ?? '');
                $slug = Security::clean($_POST['slug'] ?? '');
                $type = Security::clean($_POST['type'] ?? 'popup');
                $title = Security::clean($_POST['title'] ?? '');
                $description = Security::clean($_POST['description'] ?? '');
                $submit_button_text = Security::clean($_POST['submit_button_text'] ?? 'Submit');
                $success_message = Security::clean($_POST['success_message'] ?? '');
                $email_notification = isset($_POST['email_notification']) ? 1 : 0;
                $email_to = Security::clean($_POST['email_to'] ?? '');
                $status = Security::clean($_POST['status'] ?? 'active');
                
                // Generate slug if empty
                if (empty($slug)) {
                    $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $name));
                }
                
                // Validate
                if (empty($name)) {
                    $error = 'Form name is required.';
                    break;
                }
                
                $formData = [
                    'name' => $name,
                    'slug' => $slug,
                    'type' => $type,
                    'title' => $title,
                    'description' => $description,
                    'submit_button_text' => $submit_button_text,
                    'success_message' => $success_message,
                    'email_notification' => $email_notification,
                    'email_to' => $email_to,
                    'status' => $status
                ];
                
                try {
                    if ($id > 0) {
                        $db->update('forms', $formData, ['id' => $id]);
                        $success = 'Form updated successfully.';
                    } else {
                        $db->insert('forms', $formData);
                        $success = 'Form created successfully.';
                    }
                } catch (Exception $e) {
                    $error = 'Error saving form: ' . $e->getMessage();
                }
                break;
                
            case 'delete':
                $id = (int)($_POST['id'] ?? 0);
                if ($id > 0) {
                    try {
                        $db->delete('forms', ['id' => $id]);
                        $success = 'Form deleted successfully.';
                    } catch (Exception $e) {
                        $error = 'Error deleting form: ' . $e->getMessage();
                    }
                }
                break;
        }
    }
}

// Get all forms
$forms = $db->fetchAll("SELECT f.*, 
    (SELECT COUNT(*) FROM form_fields WHERE form_id = f.id) as field_count,
    (SELECT COUNT(*) FROM form_submissions WHERE form_id = f.id) as submission_count
    FROM forms f ORDER BY f.created_at DESC");

// Get form for editing
$editForm = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $editForm = $db->fetch("SELECT * FROM forms WHERE id = ?", [$editId]);
}

$pageTitle = 'Forms';
require_once __DIR__ . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Forms</h1>
        <p class="page-subtitle">Manage generic, popup, and contact forms</p>
    </div>
    <button class="btn btn-primary" onclick="showFormModal()">
        <i class="fas fa-plus"></i> Create Form
    </button>
</div>

<?php if ($error): ?>
<div class="alert alert-error"><?= e($error) ?></div>
<?php endif; ?>

<?php if ($success): ?>
<div class="alert alert-success"><?= e($success) ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-body" style="padding: 0;">
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Form Name</th>
                        <th>Type</th>
                        <th>Fields</th>
                        <th>Submissions</th>
                        <th>Status</th>
                        <th style="width: 150px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($forms)): ?>
                    <tr>
                        <td colspan="6" class="text-center" style="padding: 30px;">
                            <div class="empty-state">
                                <i class="fas fa-wpforms"></i>
                                <h3>No Forms Found</h3>
                                <p>Create your first form to get started.</p>
                            </div>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($forms as $form): ?>
                    <tr>
                        <td>
                            <strong><?= e($form['name']) ?></strong>
                            <div style="font-size: 12px; color: var(--color-gray-500);">/<?= e($form['slug']) ?></div>
                        </td>
                        <td>
                            <span class="status-badge" style="background: #f5f5f5; color: #666;">
                                <?= ucfirst($form['type']) ?>
                            </span>
                        </td>
                        <td>
                            <a href="form-fields.php?form_id=<?= $form['id'] ?>" class="btn btn-sm btn-secondary">
                                <i class="fas fa-list"></i> <?= $form['field_count'] ?> Fields
                            </a>
                        </td>
                        <td>
                            <a href="form-submissions.php?form_id=<?= $form['id'] ?>" class="btn btn-sm btn-secondary">
                                <i class="fas fa-inbox"></i> <?= $form['submission_count'] ?> Submissions
                            </a>
                        </td>
                        <td>
                            <span class="status-badge status-<?= $form['status'] ?>">
                                <?= ucfirst($form['status']) ?>
                            </span>
                        </td>
                        <td>
                            <div class="table-actions">
                                <a href="form-fields.php?form_id=<?= $form['id'] ?>" title="Manage Fields">
                                    <i class="fas fa-list"></i>
                                </a>
                                <button type="button" onclick="editForm(<?= e(json_encode($form)) ?>)" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button type="button" class="delete" onclick="deleteForm(<?= $form['id'] ?>, '<?= e($form['name']) ?>')" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Form Modal -->
<div id="formModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Create Form</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" id="formForm">
            <input type="hidden" name="csrf_token" value="<?= Security::generateCSRFToken() ?>">
            <input type="hidden" name="action" id="formAction" value="create">
            <input type="hidden" name="id" id="formId" value="0">
            
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Form Name *</label>
                        <input type="text" id="name" name="name" required placeholder="e.g., Contact Form">
                    </div>
                    <div class="form-group">
                        <label for="slug">Slug</label>
                        <input type="text" id="slug" name="slug" placeholder="Auto-generated if empty">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="type">Form Type</label>
                        <select id="type" name="type">
                            <option value="popup">Popup</option>
                            <option value="embedded">Embedded</option>
                            <option value="contact">Contact Page</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="title">Form Title</label>
                    <input type="text" id="title" name="title" placeholder="e.g., Get a Free Consultation">
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="2" placeholder="Brief description shown below the title"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="submit_button_text">Submit Button Text</label>
                        <input type="text" id="submit_button_text" name="submit_button_text" value="Submit">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="success_message">Success Message</label>
                    <textarea id="success_message" name="success_message" rows="2" placeholder="Thank you! Your submission has been received."></textarea>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="email_notification" name="email_notification" checked>
                        Send email notification on submission
                    </label>
                </div>
                
                <div class="form-group" id="emailToGroup">
                    <label for="email_to">Notification Email</label>
                    <input type="email" id="email_to" name="email_to" placeholder="Leave empty to use default contact email">
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Form</button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Form -->
<form id="deleteForm" method="POST" style="display: none;">
    <input type="hidden" name="csrf_token" value="<?= Security::generateCSRFToken() ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<style>
.modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
    z-index: 1000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}
.modal.active {
    display: flex;
}
.modal-content {
    background: #fff;
    border-radius: 12px;
    width: 100%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
}
.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    border-bottom: 1px solid #eee;
}
.modal-header h3 {
    margin: 0;
}
.modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #666;
}
.modal-body {
    padding: 20px;
}
.modal-footer {
    padding: 20px;
    border-top: 1px solid #eee;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}
.badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
}
.badge-primary {
    background: #000;
    color: #fff;
}
.badge-secondary {
    background: #e0e0e0;
    color: #333;
}
.text-link {
    color: #0066cc;
    text-decoration: none;
}
.text-link:hover {
    text-decoration: underline;
}
.checkbox-label {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
}
.checkbox-label input {
    width: auto;
}
</style>

<script>
function showFormModal() {
    document.getElementById('modalTitle').textContent = 'Create Form';
    document.getElementById('formAction').value = 'create';
    document.getElementById('formId').value = '0';
    document.getElementById('formForm').reset();
    document.getElementById('email_notification').checked = true;
    document.getElementById('formModal').classList.add('active');
}

function editForm(form) {
    document.getElementById('modalTitle').textContent = 'Edit Form';
    document.getElementById('formAction').value = 'update';
    document.getElementById('formId').value = form.id;
    document.getElementById('name').value = form.name;
    document.getElementById('slug').value = form.slug;
    document.getElementById('type').value = form.type;
    document.getElementById('title').value = form.title || '';
    document.getElementById('description').value = form.description || '';
    document.getElementById('submit_button_text').value = form.submit_button_text || 'Submit';
    document.getElementById('success_message').value = form.success_message || '';
    document.getElementById('email_notification').checked = form.email_notification == 1;
    document.getElementById('email_to').value = form.email_to || '';
    document.getElementById('status').value = form.status;
    document.getElementById('formModal').classList.add('active');
}

function closeModal() {
    document.getElementById('formModal').classList.remove('active');
}

function deleteForm(id, name) {
    if (confirm('Are you sure you want to delete "' + name + '"? This will also delete all fields and submissions.')) {
        document.getElementById('deleteId').value = id;
        document.getElementById('deleteForm').submit();
    }
}

// Close modal on escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeModal();
    }
});

// Close modal on background click
document.getElementById('formModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
