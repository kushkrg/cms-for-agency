<?php
/**
 * Evolvcode CMS - Admin Settings
 */

$pageTitle = 'Settings';
require_once __DIR__ . '/includes/header.php';

$db = Database::getInstance();
$message = '';
$error = '';

// Handle form submission
if (Security::isPost()) {
    $token = $_POST[CSRF_TOKEN_NAME] ?? '';
    if (!Security::validateCSRFToken($token)) {
        $error = 'Invalid form submission.';
    } else {
        // Update settings
        $settings = [
            'site_name' => Security::clean($_POST['site_name'] ?? ''),
            'site_tagline' => Security::clean($_POST['site_tagline'] ?? ''),
            'site_description' => Security::clean($_POST['site_description'] ?? ''),
            'contact_email' => Security::clean($_POST['contact_email'] ?? ''),
            'contact_phone' => Security::clean($_POST['contact_phone'] ?? ''),
            'whatsapp_number' => Security::clean($_POST['whatsapp_number'] ?? ''),
            'address' => Security::clean($_POST['address'] ?? ''),
            'facebook_url' => Security::clean($_POST['facebook_url'] ?? ''),
            'twitter_url' => Security::clean($_POST['twitter_url'] ?? ''),
            'linkedin_url' => Security::clean($_POST['linkedin_url'] ?? ''),
            'instagram_url' => Security::clean($_POST['instagram_url'] ?? ''),
            'youtube_url' => Security::clean($_POST['youtube_url'] ?? ''),
            'footer_text' => Security::clean($_POST['footer_text'] ?? ''),
            'google_analytics' => Security::clean($_POST['google_analytics'] ?? ''),
            // SMTP Settings
            'smtp_host' => Security::clean($_POST['smtp_host'] ?? ''),
            'smtp_port' => Security::clean($_POST['smtp_port'] ?? '587'),
            'smtp_user' => Security::clean($_POST['smtp_user'] ?? ''),
            'smtp_encryption' => Security::clean($_POST['smtp_encryption'] ?? 'tls'),
            'smtp_from_email' => Security::clean($_POST['smtp_from_email'] ?? ''),
            'smtp_from_name' => Security::clean($_POST['smtp_from_name'] ?? ''),
            // reCAPTCHA Settings
            'recaptcha_site_key' => Security::clean($_POST['recaptcha_site_key'] ?? ''),
            'recaptcha_secret_key' => Security::clean($_POST['recaptcha_secret_key'] ?? ''),
        ];
        
        // Only update password if provided
        if (!empty($_POST['smtp_pass'])) {
            $settings['smtp_pass'] = $_POST['smtp_pass'];
        }
        
        foreach ($settings as $key => $value) {
            $existing = $db->fetchOne("SELECT id FROM settings WHERE setting_key = ?", [$key]);
            if ($existing) {
                $db->update('settings', ['setting_value' => $value], 'id = ?', [$existing['id']]);
            } else {
                $db->insert('settings', ['setting_key' => $key, 'setting_value' => $value]);
            }
        }
        
        // Handle logo upload
        if (!empty($_FILES['logo']['name'])) {
            $uploader = new FileUpload();
            // Assuming 'logo' directory inside uploads
            $uploadedPath = $uploader->uploadImage($_FILES['logo'], 'logo');
            
            if ($uploadedPath) {
                $existing = $db->fetchOne("SELECT id FROM settings WHERE setting_key = 'logo_path'");
                if ($existing) {
                    $db->update('settings', ['setting_value' => $uploadedPath], 'id = ?', [$existing['id']]);
                } else {
                    $db->insert('settings', ['setting_key' => 'logo_path', 'setting_value' => $uploadedPath]);
                }
            } else {
                $error = 'Logo upload failed: ' . implode(' ', $uploader->getErrors());
            }
        }
        
        $message = 'Settings saved successfully.';
    }
}

// Get current settings
$settings = [];
$rows = $db->fetchAll("SELECT setting_key, setting_value FROM settings");
foreach ($rows as $row) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Site Settings</h1>
        <p class="page-subtitle">Configure your website settings</p>
    </div>
</div>

<?php if ($message): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= e($message) ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= e($error) ?></div>
<?php endif; ?>

<form method="POST" action="" enctype="multipart/form-data">
    <?= Security::csrfField() ?>
    
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
        <!-- Main Settings -->
        <div>
            <!-- General Settings -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">General Settings</h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="site_name" class="form-label">Site Name</label>
                        <input type="text" name="site_name" id="site_name" class="form-control" 
                               value="<?= e($settings['site_name'] ?? 'Evolvcode Solutions') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="site_tagline" class="form-label">Tagline</label>
                        <input type="text" name="site_tagline" id="site_tagline" class="form-control" 
                               value="<?= e($settings['site_tagline'] ?? '') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="site_description" class="form-label">Site Description</label>
                        <textarea name="site_description" id="site_description" class="form-control" 
                                  rows="3"><?= e($settings['site_description'] ?? '') ?></textarea>
                        <p class="form-text">Used for SEO meta description.</p>
                    </div>
                </div>
            </div>
            
            <!-- Contact Info -->
            <div class="card" style="margin-top: 24px;">
                <div class="card-header">
                    <h3 class="card-title">Contact Information</h3>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="contact_email" class="form-label">Email Address</label>
                            <input type="email" name="contact_email" id="contact_email" class="form-control" 
                                   value="<?= e($settings['contact_email'] ?? '') ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="contact_phone" class="form-label">Phone Number</label>
                            <input type="text" name="contact_phone" id="contact_phone" class="form-control" 
                                   value="<?= e($settings['contact_phone'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="whatsapp_number" class="form-label">WhatsApp Number</label>
                        <input type="text" name="whatsapp_number" id="whatsapp_number" class="form-control" 
                               value="<?= e($settings['whatsapp_number'] ?? '') ?>" 
                               placeholder="e.g., 919229045881 (without + sign)">
                    </div>
                    
                    <div class="form-group">
                        <label for="address" class="form-label">Address</label>
                        <textarea name="address" id="address" class="form-control" 
                                  rows="2"><?= e($settings['address'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
            
            <!-- Social Media -->
            <div class="card" style="margin-top: 24px;">
                <div class="card-header">
                    <h3 class="card-title">Social Media Links</h3>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="facebook_url" class="form-label">
                                <i class="fab fa-facebook"></i> Facebook URL
                            </label>
                            <input type="url" name="facebook_url" id="facebook_url" class="form-control" 
                                   value="<?= e($settings['facebook_url'] ?? '') ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="twitter_url" class="form-label">
                                <i class="fab fa-twitter"></i> Twitter URL
                            </label>
                            <input type="url" name="twitter_url" id="twitter_url" class="form-control" 
                                   value="<?= e($settings['twitter_url'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="linkedin_url" class="form-label">
                                <i class="fab fa-linkedin"></i> LinkedIn URL
                            </label>
                            <input type="url" name="linkedin_url" id="linkedin_url" class="form-control" 
                                   value="<?= e($settings['linkedin_url'] ?? '') ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="instagram_url" class="form-label">
                                <i class="fab fa-instagram"></i> Instagram URL
                            </label>
                            <input type="url" name="instagram_url" id="instagram_url" class="form-control" 
                                   value="<?= e($settings['instagram_url'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="youtube_url" class="form-label">
                            <i class="fab fa-youtube"></i> YouTube URL
                        </label>
                        <input type="url" name="youtube_url" id="youtube_url" class="form-control" 
                               value="<?= e($settings['youtube_url'] ?? '') ?>">
                    </div>
                </div>
            </div>
            
            <!-- Advanced -->
            <div class="card" style="margin-top: 24px;">
                <div class="card-header">
                    <h3 class="card-title">Advanced Settings</h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="footer_text" class="form-label">Footer Copyright Text</label>
                        <input type="text" name="footer_text" id="footer_text" class="form-control" 
                               value="<?= e($settings['footer_text'] ?? '© ' . date('Y') . ' Evolvcode Solutions. All rights reserved.') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="google_analytics" class="form-label">Google Analytics ID</label>
                        <input type="text" name="google_analytics" id="google_analytics" class="form-control" 
                               value="<?= e($settings['google_analytics'] ?? '') ?>" 
                               placeholder="e.g., G-XXXXXXXXXX">
                    </div>
                </div>
            </div>

            <!-- Google reCAPTCHA v3 Settings -->
            <div class="card" style="margin-top: 24px;">
                <div class="card-header">
                    <h3 class="card-title">Google reCAPTCHA v3</h3>
                </div>
                <div class="card-body">
                    <p class="form-text" style="margin-bottom: 16px;">
                        Protect your forms from spam. Get your keys from the <a href="https://www.google.com/recaptcha/admin/create" target="_blank">Google reCAPTCHA Admin Console</a>.
                    </p>
                    <div class="form-group">
                        <label for="recaptcha_site_key" class="form-label">Site Key</label>
                        <input type="text" name="recaptcha_site_key" id="recaptcha_site_key" class="form-control" 
                               value="<?= e($settings['recaptcha_site_key'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label for="recaptcha_secret_key" class="form-label">Secret Key</label>
                        <input type="text" name="recaptcha_secret_key" id="recaptcha_secret_key" class="form-control" 
                               value="<?= e($settings['recaptcha_secret_key'] ?? '') ?>">
                    </div>
                </div>
            </div>
            
            <!-- SMTP Email Settings -->
            <div class="card" style="margin-top: 24px;">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-envelope"></i> Email (SMTP) Settings</h3>
                </div>
                <div class="card-body">
                    <p class="form-text" style="margin-bottom: 16px;">
                        Configure SMTP to send form notification emails. Leave empty to use PHP's default mail function.
                    </p>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="smtp_host" class="form-label">SMTP Host</label>
                            <input type="text" name="smtp_host" id="smtp_host" class="form-control" 
                                   value="<?= e($settings['smtp_host'] ?? '') ?>" 
                                   placeholder="e.g., smtp.gmail.com">
                        </div>
                        
                        <div class="form-group">
                            <label for="smtp_port" class="form-label">SMTP Port</label>
                            <input type="number" name="smtp_port" id="smtp_port" class="form-control" 
                                   value="<?= e($settings['smtp_port'] ?? '587') ?>" 
                                   placeholder="587">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="smtp_user" class="form-label">SMTP Username</label>
                            <input type="text" name="smtp_user" id="smtp_user" class="form-control" 
                                   value="<?= e($settings['smtp_user'] ?? '') ?>" 
                                   placeholder="your@email.com">
                        </div>
                        
                        <div class="form-group">
                            <label for="smtp_pass" class="form-label">SMTP Password</label>
                            <input type="password" name="smtp_pass" id="smtp_pass" class="form-control" 
                                   placeholder="<?= !empty($settings['smtp_pass']) ? '••••••••' : 'Enter password' ?>">
                            <?php if (!empty($settings['smtp_pass'])): ?>
                            <small class="form-text">Leave empty to keep existing password</small>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="smtp_encryption" class="form-label">Encryption</label>
                        <select name="smtp_encryption" id="smtp_encryption" class="form-control">
                            <option value="tls" <?= ($settings['smtp_encryption'] ?? 'tls') === 'tls' ? 'selected' : '' ?>>TLS (Recommended)</option>
                            <option value="ssl" <?= ($settings['smtp_encryption'] ?? '') === 'ssl' ? 'selected' : '' ?>>SSL</option>
                            <option value="none" <?= ($settings['smtp_encryption'] ?? '') === 'none' ? 'selected' : '' ?>>None</option>
                        </select>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="smtp_from_email" class="form-label">From Email</label>
                            <input type="email" name="smtp_from_email" id="smtp_from_email" class="form-control" 
                                   value="<?= e($settings['smtp_from_email'] ?? '') ?>" 
                                   placeholder="noreply@yourdomain.com">
                        </div>
                        
                        <div class="form-group">
                            <label for="smtp_from_name" class="form-label">From Name</label>
                            <input type="text" name="smtp_from_name" id="smtp_from_name" class="form-control" 
                                   value="<?= e($settings['smtp_from_name'] ?? '') ?>" 
                                   placeholder="Your Company Name">
                        </div>
                    </div>
                    
                    <div class="form-group" style="margin-top: 16px;">
                        <button type="button" id="testSmtpBtn" class="btn btn-secondary" onclick="testSmtp()">
                            <i class="fas fa-paper-plane"></i> Test SMTP Connection
                        </button>
                        <span id="smtpTestResult" style="margin-left: 12px;"></span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Actions</h3>
                </div>
                <div class="card-body">
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-save"></i> Save Settings
                    </button>
                </div>
            </div>
            
            <div class="card" style="margin-top: 24px;">
                <div class="card-header">
                    <h3 class="card-title">Site Logo</h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <input type="file" name="logo" id="logo" class="form-control" 
                               accept="image/*" data-preview="logo-preview">
                        <?php if (!empty($settings['logo_path'])): ?>
                        <img src="<?= e(SITE_URL . $settings['logo_path']) ?>" id="logo-preview" 
                             style="margin-top: 12px; max-width: 100%; border-radius: 8px;">
                        <?php else: ?>
                        <img id="logo-preview" style="margin-top: 12px; max-width: 100%; border-radius: 8px; display: none;">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<style>
@media (max-width: 1024px) {
    div[style*="grid-template-columns: 2fr 1fr"] {
        grid-template-columns: 1fr !important;
    }
}
</style>

<script>
function testSmtp() {
    const btn = document.getElementById('testSmtpBtn');
    const resultSpan = document.getElementById('smtpTestResult');
    
    // Original button text
    const originalText = btn.innerHTML;
    
    // Show loading state
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Testing...';
    resultSpan.className = '';
    resultSpan.innerHTML = '';
    
    // Call API
    fetch('<?= e(SITE_URL) ?>/api/smtp-test.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                resultSpan.className = 'text-success';
                resultSpan.innerHTML = '<i class="fas fa-check-circle"></i> ' + data.message;
            } else {
                resultSpan.className = 'text-danger';
                resultSpan.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + data.message;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            resultSpan.className = 'text-danger';
            resultSpan.innerHTML = '<i class="fas fa-exclamation-circle"></i> Connection error';
        })
        .finally(() => {
            // Restore button
            btn.disabled = false;
            btn.innerHTML = originalText;
        });
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
